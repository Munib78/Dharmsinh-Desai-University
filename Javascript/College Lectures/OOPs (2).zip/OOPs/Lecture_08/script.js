//Example 1:

// const r = new Rectangle(10, 20);
// class Rectangle {
//     constructor(height, width) {
//         this.height = height;
//         this.width = width;
//     }
// }
// const rect1 = new Rectangle(20, 30);
// console.dir(rect1);

// const r2 = new Rect(20, 30);
// function Rect(h, w) {
//     this.height = h;
//     this.width = w;
// }
// const rect2 = new Rect(20, 30);
// console.dir(rect2);

///////////////////////////////////////////
// Example 2:
// let Rectangle = class {
//     constructor(height, width) {
//         this.height = height;
//         this.width = width;
//     }
// };
// console.dir(Rectangle);
// console.dir(Rectangle.name);

// let Rectangle = class Rectangle2 {
//     constructor(height, width) {
//         this.height = height;
//         this.width = width;
//     }
// };
// console.dir(Rectangle);
// console.dir(Rectangle.name);

/////////////////////////////////////////////
// Example 3:
// class Rectangle {
//     constructor(height, width) {
//         this.height = height;
//         this.width = width;
//     }

//     findArea() {
//         return this.height * this.width;
//     }
// }
// // console.dir(Rectangle);
// const rect1 = new Rectangle(20, 30);
// console.dir(rect1);

// function Rect(h, w) {
//     this.height = h;
//     this.width = w;
//     // this.findArea = function() {
//     //     return this.height * this.width;
//     // };
// }
// Rect.prototype.findArea = function() {
//     return this.height * this.width;
// };
// const rect2 = new Rect(20, 30);
// console.dir(rect2);

////////////////////////////////////////////////
// Example 4:
// class Person {
//     constructor(firstName, lastName) {
//         this.firstName = firstName;
//         this.lastName = lastName;
//     }
//     get fullName() {
//         return this.firstName + " " + this.lastName;
//     }

//     set fullName(fname) {
//         if (fname.includes(" ")) {
//             [this.firstName, this.lastName] = fname.split(" ");
//         } else console.log("Given name is not a full name");
//     }
// }
// let p = new Person("Sachin", "Tendulkar");
// console.log(p.fullName);
// // p.fullName = "Rohit";
// // p.fullName = "Rohit Sharma";
// // console.log(p.fullName);

// console.log(Object.hasOwnProperty(p.fullName));
// console.dir(p);
// console.log(Object.getOwnPropertyDescriptors(p));

// class User {
//     constructor(name) {
//         this.name = name;
//     }
//     get name() {
//         return this._name;
//     }
//     set name(value) {
//         if (value.length < 3) {
//             console.log("Name is too short.");
//             return;
//         }
//         this._name = value;
//     }
// }
// let user = new User("Virat");
// console.dir(user);
// console.log(user.name);
// user = new User("");

// console.dir(Object.getOwnPropertyDescriptors(user));

//////////////////////////////////////////////////////////////
// Example 5:
// class Point {
//     constructor(x, y) {
//         this.x = x;
//         this.y = y;
//     }

//     static distance(a, b) {
//         const dx = a.x - b.x;
//         const dy = a.y - b.y;

//         return Math.hypot(dx, dy);
//     }

//     display() {
//         return `(${this.x},${this.y})`;
//     }
// }
// const p1 = new Point(8, 9);
// const p2 = new Point(5, 5);
// console.log(
//     `Distance between ${p1.display()} and ${p2.display()} : ${Point.distance(
//     p1,
//     p2
//   )}`
// );

// console.dir(Point);
// console.log(p1.distance);

///////////////////////////////////////////////////////////////////////
// Example 6: Object.create()

// var person = Object.create(null);

// console.log(typeof person);
// console.log(person);

// // Set property to person object
// person.name = "Virat";
// console.log(person);

////////////////////////////
// prototypeObject = {
//     fullName: function() {
//         return this.firstName + " " + this.lastName;
//     },
// };
// var person = Object.create(prototypeObject);

// console.log(typeof person);
// console.dir(person);

// // // // Adding properties to the person object
// person.firstName = "Virat";
// person.lastName = "Kohli";

// // console.log(person);

// console.log(person.fullName());

// for (var prop in person) {
//     console.log(prop);
// }

// console.log(Object.keys(person));
///////////////////////////
prototypeObject = {
    fullName: function() {
        return this.firstName + " " + this.lastName;
    },
};

var person = Object.create(prototypeObject, {
    firstName: {
        value: "Virat",
        writable: true,
        enumerable: true,
    },
    lastName: {
        value: "Kohli",
        
    },
});

console.log(person);

console.log(Object.keys(person));

for (var prop in person) {
    console.log(prop);
}