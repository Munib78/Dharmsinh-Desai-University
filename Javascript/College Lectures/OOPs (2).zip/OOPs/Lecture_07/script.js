"use strict";

function Person(firstName, birthYear) {
    // Instance properties
    this.firstName = firstName;
    this.birthYear = birthYear;
}

var person1 = new Person("Sachin", 1973);
console.log(person1);

Person.prototype.calcAge = function() {
    return new Date().getFullYear() - this.birthYear;
};

var person2 = new Person("Rohit", 1987);
console.log(person2);
console.log(`${person2.firstName}'s age is ${person2.calcAge()}`);

console.log(Person.prototype);
console.log(person1.__proto__);
console.log(person1.__proto__ === Person.prototype);

console.log(Person.prototype.isPrototypeOf(person1));
console.log(Person.prototype.isPrototypeOf(person2));
console.log(Person.prototype.isPrototypeOf(Person));
console.dir(Person.__proto__);

// .prototyeOfLinkedObjects

// Person.prototype.species = "Homo Sapiens";
// console.log(person1.species, person2.species);

// console.log(person1.hasOwnProperty("firstName"));
// console.log(person1.hasOwnProperty("species"));

///////////////////////////////////////
// Prototypal Inheritance on Built-In Objects

// console.dir(person1.__proto__);
// // Object.prototype (top of prototype chain)
// console.dir(person1.__proto__.__proto__);
// console.dir(person1.__proto__.__proto__.__proto__);

// console.dir(Person.prototype.constructor);

// const arr = [3, 6, 6, 5, 6, 9, 9]; // new Array === []
// console.log(arr.__proto__);
// console.log(arr.__proto__ === Array.prototype);

// console.log(arr.__proto__.__proto__);

// // Modifying prototype of built-in object - Not Recommended
// Array.prototype.unique = function() {
//     return [...new Set(this)];
// };

// console.log(arr.unique());

// Functions do have their own __proto__ / [[Prototype]]
// console.dir((x) => x + 1);