let para = document.getElementById("demo");
para.style.color = "blue";
alert("Ready ?");
para.innerHTML = "<b>Example of Synchronous JS Program</b>";
